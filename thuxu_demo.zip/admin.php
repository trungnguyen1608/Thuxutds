<?php
require "config.php";
if ($_SESSION["role"] !== "admin") { die("Access denied"); }

if (isset($_GET["done"])) {
    $id = (int)$_GET["done"];
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id=?");
    $stmt->execute([$id]);
    $order = $stmt->fetch();

    if ($order) {
        $pdo->prepare("UPDATE users SET balance_vnd = balance_vnd + ? WHERE id=?")
            ->execute([$order["amount_vnd"], $order["user_id"]]);

        $pdo->prepare("UPDATE users SET balance_xu = balance_xu - ? WHERE id=?")
            ->execute([$order["amount_xu"], $order["user_id"]]);

        $pdo->prepare("UPDATE orders SET status='done' WHERE id=?")->execute([$id]);
    }
}

$orders = $pdo->query("SELECT o.*, u.username FROM orders o JOIN users u ON o.user_id=u.id ORDER BY o.id DESC")->fetchAll();
?>
<h2>Admin Panel</h2>
<table border="1">
<tr><th>ID</th><th>User</th><th>Xu</th><th>VNĐ</th><th>Status</th><th>Action</th></tr>
<?php foreach ($orders as $o): ?>
<tr>
    <td><?= $o["id"] ?></td>
    <td><?= $o["username"] ?></td>
    <td><?= $o["amount_xu"] ?></td>
    <td><?= $o["amount_vnd"] ?></td>
    <td><?= $o["status"] ?></td>
    <td><?php if ($o["status"]=="pending") echo "<a href='?done={$o["id"]}'>Duyệt</a>"; ?></td>
</tr>
<?php endforeach; ?>
</table>