<?php
$host = "localhost"; // đổi theo InfinityFree MySQL host
$db   = "demo_db";
$user = "demo_user";
$pass = "demo_pass";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("DB connect failed: " . $e->getMessage());
}
session_start();
?>