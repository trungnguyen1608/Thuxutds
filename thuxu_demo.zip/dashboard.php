<?php
require "config.php";
if (!isset($_SESSION["user_id"])) { header("Location: index.php"); exit; }

$stmt = $pdo->prepare("SELECT * FROM users WHERE id=?");
$stmt->execute([$_SESSION["user_id"]]);
$user = $stmt->fetch();
?>
<h2>Xin chào, <?= htmlspecialchars($user["username"]) ?></h2>
<p>Balance Xu: <?= $user["balance_xu"] ?></p>
<p>Balance VNĐ: <?= $user["balance_vnd"] ?></p>
<a href="order.php">Bán Xu</a> | <a href="logout.php">Đăng xuất</a>
<?php if ($_SESSION["role"] === "admin") echo '<p><a href="admin.php">Admin Panel</a></p>'; ?>