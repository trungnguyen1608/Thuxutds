<?php
// Website by Mr Trung - Giao diện hiện đại
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website by Mr Trung</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            color: #fff;
        }
        /* Banner cố định */
        .banner {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: rgba(255, 204, 0, 0.95);
            padding: 12px;
            text-align: center;
            font-weight: bold;
            z-index: 1000;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
            color: #000;
        }
        .banner a {
            color: blue;
            text-decoration: none;
            margin: 0 5px;
        }
        .banner a:hover {
            text-decoration: underline;
        }
        /* Ảnh nền */
        .hero {
            background: url('https://picsum.photos/1920/1080?blur=3') no-repeat center center/cover;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            position: relative;
        }
        /* Lớp mờ */
        .hero::before {
            content: "";
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.5);
        }
        /* Nội dung chính */
        .content {
            position: relative;
            z-index: 1;
            max-width: 700px;
            padding: 30px;
            background: rgba(255,255,255,0.1);
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.5);
        }
        h1 {
            font-size: 2.5rem;
            margin-bottom: 20px;
        }
        p {
            font-size: 1.1rem;
            margin-bottom: 20px;
        }
        .btn {
            display: inline-block;
            padding: 12px 25px;
            background: #ffcc00;
            color: #000;
            font-weight: bold;
            border-radius: 8px;
            text-decoration: none;
            transition: 0.3s;
        }
        .btn:hover {
            background: #e6b800;
        }
    </style>
</head>
<body>
    <!-- Banner Admin -->
    <div class="banner">
        🌐 Website by <span style="color:red;">Mr Trung</span> | 
        📱 Zalo: <a href="tel:0869234153">0869234153</a> | 
        📘 Facebook: <a href="https://www.facebook.com/share/1FojkDP3zX/" target="_blank">Click here</a>
    </div>

    <!-- Hero Section với ảnh nền -->
    <div class="hero">
        <div class="content">
            <h1>Chào mừng bạn đến với Website!</h1>
            <p>Website hiện đang trong quá trình chờ duyệt tên miền (tối đa 72h).</p>
            <a href="https://zalo.me/0869234153" class="btn">Liên hệ Zalo</a>
        </div>
    </div>
</body>
</html>