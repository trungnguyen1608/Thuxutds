<?php
require "config.php";
if (!isset($_SESSION["user_id"])) { header("Location: index.php"); exit; }

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $amount = (int)$_POST["amount"];
    $rate = 10; // 1 xu = 10 VNĐ
    $vnd = $amount * $rate;

    $stmt = $pdo->prepare("INSERT INTO orders(user_id,amount_xu,amount_vnd) VALUES (?,?,?)");
    $stmt->execute([$_SESSION["user_id"], $amount, $vnd]);

    echo "Đơn hàng đã tạo (chờ admin duyệt)";
}
?>
<form method="post">
    <h3>Bán Xu</h3>
    <input name="amount" type="number" placeholder="Nhập số xu">
    <button type="submit">Tạo đơn</button>
</form>