<?php
require "config.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $u = $_POST["username"];
    $p = password_hash($_POST["password"], PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO users(username,password_hash) VALUES (?,?)");
    try {
        $stmt->execute([$u, $p]);
        echo "Đăng ký thành công! <a href='index.php'>Đăng nhập</a>";
        exit;
    } catch {
        echo "Tên tài khoản đã tồn tại!";
    }
}
?>
<form method="post">
    <h2>Đăng ký</h2>
    <input name="username" placeholder="Username">
    <input name="password" type="password" placeholder="Password">
    <button type="submit">Register</button>
</form>