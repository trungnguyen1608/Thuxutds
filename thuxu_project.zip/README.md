Thuxu - demo PHP project (minimal)
---------------------------------
Files included:
- config.php (edit DB credentials)
- db.php (PDO db connection)
- wallet.php (xu & balance helpers)
- schema.sql (import to create tables)
- auth/register.php, auth/login.php
- task/create.php, task/list.php, task/submit.php
- admin/actions.php (accept actions)

Quick setup:
1. Create MySQL database on your host.
2. Edit config.php with DB credentials.
3. Import schema.sql using phpMyAdmin.
4. Upload files to host public_html (or www).
5. Visit /auth/register.php to create users.
6. As admin, go to /admin/actions.php to accept proofs.

NOTE: This is a minimal demo; hardening (CSRF, input validation, captcha, rate-limit) needed before production.
