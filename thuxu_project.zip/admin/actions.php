<?php
// Simple admin page: list pending actions and accept them.
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../wallet.php';
$config = require __DIR__ . '/../config.php';
// VERY simple admin auth: put ?admin=1 in URL. In production replace with proper auth.
if(!isset($_GET['admin']) || $_GET['admin']!='1') die('Admin access required. Append ?admin=1');
$pdo = getPDO();
if(isset($_GET['accept'])){
    $actionId = (int)$_GET['accept'];
    // accept logic - reuse pattern: fetch action and task, then pay
    try{
        $pdo->beginTransaction();
        $stmt = $pdo->prepare('SELECT a.*, t.remaining_subs FROM actions a JOIN tasks t ON a.task_id = t.id WHERE a.id = ? FOR UPDATE');
        $stmt->execute([$actionId]);
        $row = $stmt->fetch();
        if(!$row) throw new Exception('Action not found');
        if($row['status'] !== 'pending') throw new Exception('Already processed');
        $actorId = $row['actor_id']; $subs = (int)$row['subs_count']; $taskId = $row['task_id'];
        $rate = $config['RATE_SUB_PER_XU']; $xuToVnd = $config['XU_TO_VND']; $auto = $config['AUTO_CONVERT_XU'];
        $xuEarned = (int)floor($subs / $rate);
        if($xuEarned > 0){
            if($auto){
                $vnd = $xuEarned * $xuToVnd;
                changeBalance($pdo, $actorId, $vnd, 'Earn from action '.$actionId, $actionId);
            } else {
                changeXu($pdo, $actorId, $xuEarned, 'Earn from action '.$actionId, $actionId);
            }
        }
        // update action and task remaining_subs
        $stmt = $pdo->prepare("UPDATE actions SET status='accepted' WHERE id = ?");
        $stmt->execute([$actionId]);
        $newRem = max(0, $row['remaining_subs'] - $subs);
        $status = ($newRem == 0)?'done':'open';
        $stmt = $pdo->prepare('UPDATE tasks SET remaining_subs = ?, status = ? WHERE id = ?');
        $stmt->execute([$newRem, $status, $taskId]);
        $pdo->commit();
        echo "<p style='color:green'>Accepted action {$actionId}</p>";
    } catch(Exception $e){
        $pdo->rollBack();
        echo '<p style="color:red">Error: '.htmlspecialchars($e->getMessage()).'</p>';
    }
}
$stmt = $pdo->query("SELECT a.*, u.username as actor, t.title FROM actions a JOIN users u ON a.actor_id = u.id JOIN tasks t ON a.task_id = t.id WHERE a.status = 'pending' ORDER BY a.created_at DESC");
$actions = $stmt->fetchAll();
?>
<!DOCTYPE html><html><head><meta charset='utf-8'><title>Admin Actions</title></head><body>
<h2>Pending Actions</h2>
<?php foreach($actions as $a): ?>
  <div style='border:1px solid #ccc;padding:10px;margin:10px'>
    <strong>Action #<?php echo $a['id']; ?></strong><br>
    Actor: <?php echo htmlspecialchars($a['actor']); ?><br>
    Task: <?php echo htmlspecialchars($a['title']); ?><br>
    Proof: <?php echo htmlspecialchars($a['proof']); ?><br>
    Subs: <?php echo $a['subs_count']; ?><br>
    <a href='?admin=1&accept=<?php echo $a['id']; ?>'>Accept</a>
  </div>
<?php endforeach; ?>
</body></html>
