<?php
session_start();
require_once __DIR__ . '/../db.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if($user && password_verify($password, $user['password_hash'])){
        $_SESSION['user_id'] = $user['id'];
        header('Location: /'); exit;
    } else { $err='Login failed'; }
}
?>
<!DOCTYPE html><html><head><meta charset='utf-8'><title>Login</title></head><body>
<h2>Login</h2>
<?php if(isset($err)) echo '<p style="color:red">'.htmlspecialchars($err).'</p>';?>
<form method='post'>
Username: <input name='username'><br>
Password: <input type='password' name='password'><br>
<button>Login</button>
</form>
</body></html>
