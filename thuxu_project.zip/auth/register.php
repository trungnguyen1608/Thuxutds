<?php
require_once __DIR__ . '/../db.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    if(!$username || !$password){ $err='Missing'; }
    else{
        $pdo = getPDO();
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('INSERT INTO users (username,password_hash) VALUES (?,?)');
        try{ $stmt->execute([$username,$hash]); header('Location: login.php'); exit; }
        catch(Exception $e){ $err='User exists'; }
    }
}
?>
<!DOCTYPE html><html><head><meta charset='utf-8'><title>Register</title></head><body>
<h2>Register</h2>
<?php if(isset($err)) echo '<p style="color:red">'.htmlspecialchars($err).'</p>';?>
<form method='post'>
Username: <input name='username'><br>
Password: <input type='password' name='password'><br>
<button>Register</button>
</form>
</body></html>
