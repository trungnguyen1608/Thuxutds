<?php
// config.php
return [
  'db' => [
    'host' => 'localhost',
    'dbname' => 'thuxu_db',
    'user' => 'db_user',
    'pass' => 'db_pass',
    'charset' => 'utf8mb4'
  ],
  'RATE_SUB_PER_XU' => 10,    // 10 sub = 1 xu
  'XU_TO_VND' => 1000,        // 1 xu = 1000 VND
  'AUTO_CONVERT_XU' => true   // auto convert xu -> VND on accept
];
