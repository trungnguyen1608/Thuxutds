<?php
// db.php
$config = require __DIR__ . '/config.php';
$cfgDB = $config['db'];
function getPDO(){
    global $cfgDB;
    static $pdo = null;
    if($pdo === null){
        $dsn = "mysql:host={$cfgDB['host']};dbname={$cfgDB['dbname']};charset={$cfgDB['charset']}";
        $pdo = new PDO($dsn, $cfgDB['user'], $cfgDB['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
    }
    return $pdo;
}
