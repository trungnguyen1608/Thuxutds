<?php
// simple landing and links
?>
<!DOCTYPE html>
<html><head><meta charset='utf-8'><title>Thuxu</title></head><body>
<h1>Thuxu - Exchange Platform (Demo)</h1>
<ul>
  <li><a href='auth/register.php'>Register</a></li>
  <li><a href='auth/login.php'>Login</a></li>
  <li><a href='task/list.php'>View Tasks</a></li>
  <li><a href='admin/actions.php'>Admin - Actions (require manual login)</a></li>
</ul>
<p>Read README for setup steps.</p>
</body></html>
