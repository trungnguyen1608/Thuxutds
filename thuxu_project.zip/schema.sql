-- schema.sql for Thuxu project
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  email VARCHAR(100),
  xu INT DEFAULT 0,
  balance BIGINT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tasks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  owner_id INT NOT NULL,
  title VARCHAR(255),
  target_url VARCHAR(255),
  required_subs INT NOT NULL,
  xu_cost INT NOT NULL,
  remaining_subs INT NOT NULL,
  fund_vnd BIGINT DEFAULT 0,
  status ENUM('open','ongoing','done','cancelled') DEFAULT 'open',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE actions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  task_id INT,
  actor_id INT,
  proof TEXT,
  subs_count INT DEFAULT 1,
  status ENUM('pending','accepted','rejected') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
  FOREIGN KEY (actor_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  change_amount BIGINT,
  reason VARCHAR(255),
  related_id INT,
  currency ENUM('XU','VND') NOT NULL DEFAULT 'XU',
  tx_type VARCHAR(50) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
