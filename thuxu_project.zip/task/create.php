<?php
session_start();
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../wallet.php';
$config = require __DIR__ . '/../config.php';
if(!isset($_SESSION['user_id'])) die('Login required');
$uid = $_SESSION['user_id'];
if($_SERVER['REQUEST_METHOD']==='POST'){
    $title = $_POST['title'];
    $target = $_POST['target_url'];
    $req = (int)$_POST['required_subs'];
    $rate = $config['RATE_SUB_PER_XU'];
    $xu_cost = (int)ceil($req / $rate);
    $pdo = getPDO();
    try{
        $pdo->beginTransaction();
        // deduct xu from owner (must have xu)
        changeXu($pdo, $uid, -$xu_cost, 'Create task', null);
        $stmt = $pdo->prepare('INSERT INTO tasks (owner_id,title,target_url,required_subs,xu_cost,remaining_subs) VALUES (?,?,?,?,?,?)');
        $stmt->execute([$uid,$title,$target,$req,$xu_cost,$req]);
        $pdo->commit();
        header('Location: list.php'); exit;
    }catch(Exception $e){
        $pdo->rollBack();
        $err = $e->getMessage();
    }
}
?>
<!DOCTYPE html><html><head><meta charset='utf-8'><title>Create Task</title></head><body>
<h2>Create Task</h2>
<?php if(isset($err)) echo '<p style="color:red">'.htmlspecialchars($err).'</p>';?>
<form method='post'>
Title: <input name='title'><br>
Target URL: <input name='target_url'><br>
Required subs: <input name='required_subs' value='10'><br>
<button>Create (will deduct xu)</button>
</form>
</body></html>
