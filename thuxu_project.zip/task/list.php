<?php
session_start();
require_once __DIR__ . '/../db.php';
$pdo = getPDO();
$stmt = $pdo->query('SELECT t.*, u.username as owner FROM tasks t JOIN users u ON t.owner_id = u.id WHERE status = "open"');
$tasks = $stmt->fetchAll();
?>
<!DOCTYPE html><html><head><meta charset='utf-8'><title>Tasks</title></head><body>
<h2>Open Tasks</h2>
<a href='/task/create.php'>Create Task</a><br><br>
<?php foreach($tasks as $t): ?>
  <div style='border:1px solid #ccc;padding:10px;margin:10px'>
    <strong><?php echo htmlspecialchars($t['title']); ?></strong><br>
    Owner: <?php echo htmlspecialchars($t['owner']); ?><br>
    Target: <?php echo htmlspecialchars($t['target_url']); ?><br>
    Required subs: <?php echo $t['required_subs']; ?> | Remaining: <?php echo $t['remaining_subs']; ?><br>
    <a href='submit.php?task_id=<?php echo $t['id']; ?>'>Submit proof</a>
  </div>
<?php endforeach; ?>
</body></html>
