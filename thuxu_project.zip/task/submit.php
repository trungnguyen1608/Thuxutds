<?php
session_start();
require_once __DIR__ . '/../db.php';
if(!isset($_SESSION['user_id'])) die('Login required');
$uid = $_SESSION['user_id'];
$task_id = isset($_GET['task_id']) ? (int)$_GET['task_id'] : 0;
$pdo = getPDO();
if($_SERVER['REQUEST_METHOD']==='POST'){
    $proof = $_POST['proof'];
    $subs = (int)$_POST['subs_count'];
    $stmt = $pdo->prepare('INSERT INTO actions (task_id, actor_id, proof, subs_count) VALUES (?,?,?,?)');
    $stmt->execute([$task_id, $uid, $proof, $subs]);
    header('Location: /task/list.php'); exit;
}
$stmt = $pdo->prepare('SELECT * FROM tasks WHERE id = ?');
$stmt->execute([$task_id]);
$task = $stmt->fetch();
?>
<!DOCTYPE html><html><head><meta charset='utf-8'><title>Submit Proof</title></head><body>
<h2>Submit Proof for Task #<?php echo $task_id; ?></h2>
<p><?php if($task) echo htmlspecialchars($task['title']); ?></p>
<form method='post'>
Proof (image link / note): <input name='proof' style='width:80%'><br>
Subs count (usually 1): <input name='subs_count' value='1'><br>
<button>Submit (will wait admin approval)</button>
</form>
</body></html>
