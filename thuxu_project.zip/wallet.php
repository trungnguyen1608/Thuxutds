<?php
// wallet.php - helper functions for xu and balance
require_once __DIR__ . '/db.php';
function changeXu(PDO $pdo, $userId, $amount, $reason = '', $relatedId = null){
    // caller must start transaction
    $stmt = $pdo->prepare("SELECT xu FROM users WHERE id = ? FOR UPDATE");
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    if(!$row) throw new Exception('User not found (xu)');
    $new = $row['xu'] + $amount;
    if($new < 0) throw new Exception('Not enough xu');
    $stmt = $pdo->prepare("UPDATE users SET xu = ? WHERE id = ?");
    $stmt->execute([$new, $userId]);
    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, change_amount, reason, related_id, currency, tx_type) VALUES (?, ?, ?, ?, 'XU', ?)"); 
    $stmt->execute([$userId, $amount, $reason, $relatedId, ($amount>0?'earn':'spend')]);
}

function changeBalance(PDO $pdo, $userId, $amountVnd, $reason = '', $relatedId = null){
    $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ? FOR UPDATE");
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    if(!$row) throw new Exception('User not found (balance)');
    $new = $row['balance'] + $amountVnd;
    if($new < 0) throw new Exception('Not enough balance');
    $stmt = $pdo->prepare("UPDATE users SET balance = ? WHERE id = ?");
    $stmt->execute([$new, $userId]);
    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, change_amount, reason, related_id, currency, tx_type) VALUES (?, ?, ?, ?, 'VND', ?)"); 
    $stmt->execute([$userId, $amountVnd, $reason, $relatedId, ($amountVnd>0?'credit':'debit')]);
}
